# Sprout — contrast of every semantic pair

| Pair | Foreground | Background | Ratio | Needs | Result |
|---|---|---|---|---|---|
| light: text on bg | `#29302C` | `#FFFFFF` | 13.52:1 | 7:1 | Pass |
| light: muted text on surface | `#69716C` | `#F4F8F6` | 4.69:1 | 4.5:1 | Pass |
| light: control border on bg (3:1) | `#808883` | `#FFFFFF` | 3.64:1 | 3:1 | Pass |
| light: primary (links, buttons) on bg | `#128355` | `#FFFFFF` | 4.77:1 | 4.5:1 | Pass |
| light: text on primary button | `#FFFFFF` | `#128355` | 4.77:1 | 4.5:1 | Pass |
| light: focus ring on bg (3:1) | `#379C6B` | `#FFFFFF` | 3.43:1 | 3:1 | Pass |
| light: success text on success-subtle | `#056A2D` | `#E6FFE9` | 6.39:1 | 4.5:1 | Pass |
| light: warning text on warning-subtle | `#844600` | `#FFF5ED` | 6.84:1 | 4.5:1 | Pass |
| light: danger text on danger-subtle | `#A7030F` | `#FFF4F2` | 7.31:1 | 4.5:1 | Pass |
| light: info text on info-subtle | `#0D5D8C` | `#EFF8FF` | 6.60:1 | 4.5:1 | Pass |
| light: accent (non-text) on bg | `#9B71BD` | `#FFFFFF` | 3.82:1 | 3:1 | Pass |
| dark: text on bg | `#F4F8F6` | `#171C19` | 16.11:1 | 7:1 | Pass |
| dark: muted text on surface | `#B8C0BB` | `#29302C` | 7.27:1 | 4.5:1 | Pass |
| dark: control border on bg (3:1) | `#69716C` | `#171C19` | 3.44:1 | 3:1 | Pass |
| dark: primary (links, buttons) on bg | `#56B886` | `#171C19` | 7.07:1 | 4.5:1 | Pass |
| dark: text on primary button | `#171C19` | `#56B886` | 7.07:1 | 4.5:1 | Pass |
| dark: focus ring on bg (3:1) | `#379C6B` | `#171C19` | 5.04:1 | 3:1 | Pass |
| dark: success text on success-subtle | `#61DB7F` | `#002209` | 9.69:1 | 4.5:1 | Pass |
| dark: warning text on warning-subtle | `#FEA65E` | `#2C1300` | 9.02:1 | 4.5:1 | Pass |
| dark: danger text on danger-subtle | `#FEA196` | `#3A0002` | 9.11:1 | 4.5:1 | Pass |
| dark: info text on info-subtle | `#7FC6FB` | `#011D30` | 9.32:1 | 4.5:1 | Pass |
| dark: accent (non-text) on bg | `#9B71BD` | `#171C19` | 4.51:1 | 3:1 | Pass |
