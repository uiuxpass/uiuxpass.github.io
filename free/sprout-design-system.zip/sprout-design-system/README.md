# Sprout design system (free)

A complete, contrast-checked design system you can drop into a project today.
From UI/UX Pass · https://uiuxpass.com/free/ · version 1.0, November 2026

## What is inside
| File | Use it for |
|---|---|
| tokens.json | Source of truth in the W3C Design Tokens format (Style Dictionary, Tokens Studio) |
| tokens.css | CSS variables: light, dark and system preference |
| tailwind.preset.js | `presets: [require('./tailwind.preset.js')]` |
| figma-variables.json | Primitives + Semantic (Light/Dark) collections for Figma variables |
| DESIGN.md | The rules in words, for people and AI agents. Put it at your project root so Claude follows it |
| components.html | Every core component in every state, with a light/dark toggle |
| contrast.md | Proof: every text/background pair, its ratio and the WCAG 2.2 AA result |

## Measured
- 22 of 22 colour pairs pass WCAG 2.2 AA (text 4.5:1, large text and UI parts 3:1), light and dark. See contrast.md.
- components.html passes 66 of 66 automated interface checks (UI/UX Pass interface-polish, November 2026).

## Brand inputs
Primary #1F8A5B · type DM Sans, DM Mono · radius 10px · base size 16px · comfortable density.

## Licence
Free to use in personal and commercial projects, and to modify. Please do not resell the files as they are.

## Want two more systems and the script that builds your own?
Sprout is one of three systems in the design-system kit (with Ledger and Ember) in UI/UX Pass.
The design-system-starter skill builds a system like this from your own brand colour in about a minute.
https://uiuxpass.com/#pricing
