// Sprout Tailwind preset — use with tokens.css
module.exports = {
  "theme": {
    "extend": {
      "colors": {
        "bg": "var(--bg)",
        "surface": "var(--surface)",
        "surface-raised": "var(--surface-raised)",
        "text": "var(--text)",
        "text-muted": "var(--text-muted)",
        "border": "var(--border)",
        "border-subtle": "var(--border-subtle)",
        "primary": {
          "50": "var(--color-primary-50)",
          "100": "var(--color-primary-100)",
          "200": "var(--color-primary-200)",
          "300": "var(--color-primary-300)",
          "400": "var(--color-primary-400)",
          "500": "var(--color-primary-500)",
          "600": "var(--color-primary-600)",
          "700": "var(--color-primary-700)",
          "800": "var(--color-primary-800)",
          "900": "var(--color-primary-900)",
          "950": "var(--color-primary-950)"
        },
        "on-primary": "var(--on-primary)",
        "primary-hover": "var(--primary-hover)",
        "primary-subtle": "var(--primary-subtle)",
        "focus": "var(--focus)",
        "success-subtle": "var(--success-subtle)",
        "success": {
          "50": "var(--color-success-50)",
          "100": "var(--color-success-100)",
          "200": "var(--color-success-200)",
          "300": "var(--color-success-300)",
          "400": "var(--color-success-400)",
          "500": "var(--color-success-500)",
          "600": "var(--color-success-600)",
          "700": "var(--color-success-700)",
          "800": "var(--color-success-800)",
          "900": "var(--color-success-900)",
          "950": "var(--color-success-950)"
        },
        "warning-subtle": "var(--warning-subtle)",
        "warning": {
          "50": "var(--color-warning-50)",
          "100": "var(--color-warning-100)",
          "200": "var(--color-warning-200)",
          "300": "var(--color-warning-300)",
          "400": "var(--color-warning-400)",
          "500": "var(--color-warning-500)",
          "600": "var(--color-warning-600)",
          "700": "var(--color-warning-700)",
          "800": "var(--color-warning-800)",
          "900": "var(--color-warning-900)",
          "950": "var(--color-warning-950)"
        },
        "danger-subtle": "var(--danger-subtle)",
        "danger": {
          "50": "var(--color-danger-50)",
          "100": "var(--color-danger-100)",
          "200": "var(--color-danger-200)",
          "300": "var(--color-danger-300)",
          "400": "var(--color-danger-400)",
          "500": "var(--color-danger-500)",
          "600": "var(--color-danger-600)",
          "700": "var(--color-danger-700)",
          "800": "var(--color-danger-800)",
          "900": "var(--color-danger-900)",
          "950": "var(--color-danger-950)"
        },
        "info-subtle": "var(--info-subtle)",
        "info": {
          "50": "var(--color-info-50)",
          "100": "var(--color-info-100)",
          "200": "var(--color-info-200)",
          "300": "var(--color-info-300)",
          "400": "var(--color-info-400)",
          "500": "var(--color-info-500)",
          "600": "var(--color-info-600)",
          "700": "var(--color-info-700)",
          "800": "var(--color-info-800)",
          "900": "var(--color-info-900)",
          "950": "var(--color-info-950)"
        },
        "accent": {
          "50": "var(--color-accent-50)",
          "100": "var(--color-accent-100)",
          "200": "var(--color-accent-200)",
          "300": "var(--color-accent-300)",
          "400": "var(--color-accent-400)",
          "500": "var(--color-accent-500)",
          "600": "var(--color-accent-600)",
          "700": "var(--color-accent-700)",
          "800": "var(--color-accent-800)",
          "900": "var(--color-accent-900)",
          "950": "var(--color-accent-950)"
        },
        "neutral": {
          "50": "var(--color-neutral-50)",
          "100": "var(--color-neutral-100)",
          "200": "var(--color-neutral-200)",
          "300": "var(--color-neutral-300)",
          "400": "var(--color-neutral-400)",
          "500": "var(--color-neutral-500)",
          "600": "var(--color-neutral-600)",
          "700": "var(--color-neutral-700)",
          "800": "var(--color-neutral-800)",
          "900": "var(--color-neutral-900)",
          "950": "var(--color-neutral-950)"
        }
      },
      "fontFamily": {
        "heading": [
          "var(--font-heading)"
        ],
        "body": [
          "var(--font-body)"
        ],
        "mono": [
          "var(--font-mono)"
        ]
      },
      "borderRadius": {
        "none": "var(--radius-none)",
        "sm": "var(--radius-sm)",
        "md": "var(--radius-md)",
        "lg": "var(--radius-lg)",
        "xl": "var(--radius-xl)",
        "full": "var(--radius-full)"
      },
      "boxShadow": {
        "sm": "var(--shadow-sm)",
        "md": "var(--shadow-md)",
        "lg": "var(--shadow-lg)"
      },
      "spacing": {
        "0": "var(--space-0)",
        "1": "var(--space-1)",
        "2": "var(--space-2)",
        "3": "var(--space-3)",
        "4": "var(--space-4)",
        "5": "var(--space-5)",
        "6": "var(--space-6)",
        "8": "var(--space-8)",
        "10": "var(--space-10)",
        "12": "var(--space-12)",
        "16": "var(--space-16)"
      },
      "transitionDuration": {
        "fast": "var(--duration-fast)",
        "base": "var(--duration-base)",
        "slow": "var(--duration-slow)"
      }
    }
  }
};
