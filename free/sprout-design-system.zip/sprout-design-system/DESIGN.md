# Sprout — DESIGN.md

The visual system for Sprout, written for designers, developers and AI agents. Source of truth: `tokens.json` (W3C Design Tokens). CSS: `tokens.css`. Tailwind: `tailwind.preset.js`. Figma variables: `figma-variables.json`.

## Principles
- Calm surfaces, one clear primary action per view.
- Every text colour meets WCAG 2.2 AA (see `contrast.md`); UI borders and focus rings meet 3:1.
- Use semantic tokens in product code (`--primary`, `--text-muted`), never raw ramp steps.

## Colour
| Role | Light | Dark | Use |
|---|---|---|---|
| bg | #FFFFFF | #171C19 | Page background |
| surface | #F4F8F6 | #29302C | Cards, panels, table headers |
| text | #29302C | #F4F8F6 | Body and headings |
| text-muted | #69716C | #B8C0BB | Secondary text, hints |
| border | #808883 | #69716C | Inputs and controls (3:1) |
| border-subtle | #D2D9D5 | #3D4440 | Dividers only, not control edges |
| primary | #128355 | #56B886 | Primary buttons, links, selected states |
| on-primary | #FFFFFF | #171C19 | Text and icons on primary |
| focus | #379C6B | #379C6B | 2px focus ring, 2px offset |
| success / warning / danger / info | #056A2D / #844600 / #A7030F / #0D5D8C | #61DB7F / #FEA65E / #FEA196 / #7FC6FB | Status text on its -subtle background; always with an icon or word, never colour alone |

## Type
Heading: DM Sans. Body: DM Sans. Mono: DM Mono. Scale (px): xs 12, sm 14, md 16, lg 18, xl 20, 2xl 24, 3xl 30, 4xl 36, 5xl 48. Body text 16px, line height 1.5; headings 1.2 with `text-wrap: balance`. Numbers in tables use tabular figures.

## Space, radius, elevation
Spacing on a 4px grid: 0px, 4px, 8px, 12px, 16px, 20px, 24px, 32px, 40px, 48px, 64px. Radius: none 0px, sm 5px, md 10px, lg 15px, xl 20px, full 9999px. Shadows sm/md/lg for raised surfaces only. Control height 44px; touch targets at least 44px.

## Motion
Durations 120/200/320 ms; ease-out for entering, ease-in-out for moving. Animate opacity and transform only. Respect `prefers-reduced-motion`.

## Components
See `components.html`: button (primary, secondary, ghost, destructive; hover, focus, disabled, loading), input, select, textarea, checkbox, radio, switch, badge, alert, card, tabs, table, dialog, toast, empty state. Each states its rules on the page.

## Do / Don't
- Do: one primary button per view; labels above inputs; errors say how to fix.
- Don't: grey text below `text-muted`; colour-only status; borders lighter than `border` on inputs; more than two type families.
