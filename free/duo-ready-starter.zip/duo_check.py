#!/usr/bin/env python3
"""Duo-ready check: measures a screen (HTML page or URL) for iPhone Duo in a real browser.

Usage:
  python3 -I duo_check.py <page.html|url> [--pose=iphone|outer|inner|split] [--rail=left|right] [--json=out.json]
  python3 -I duo_check.py <folder> [--md=report.md]      # every *.html in the folder, pose read from each page

The pose comes from <meta name="duo-pose" content="..."> or --pose. Viewports (points = CSS px):
  iphone 393x852 (reference) · outer 466x678 (closed) · inner 951x669 (open) · split 475x669 (half of inner)

Checks (each failure names the element and the number):
  D1  Frame is the real size for the pose (inner 951x669, not the 890x626 preset)
  D2  Nothing on the fold: no text line or control inside the 24 pt band centred on x = 475.5 (open)
  D3  Open display is used: content on both halves, not a phone-width column in the middle (open)
  D4  Side rail kept clear: only the rail sits in the 84 pt leading strip; rail has 2-5 labelled tabs (closed)
  D5  Bottom tab bar has 3-5 labelled tabs (iphone, split)
  D6  No sideways scrolling at the pose size
  D7  Touch targets >= 44 x 44 pt
  D8  >= 8 pt between neighbouring targets
  D9  Text >= 11 pt; paragraphs >= 15 pt
  D10 Text at 200% does not clip (elements marked data-truncate-ok are allowed to truncate)
  D11 Status / camera area clear of controls
  D12 Text contrast: >= 4.5:1, large text >= 3:1 (WCAG 2.2 AA 1.4.3)
Sources: Apple HIG "Designing for iPhone Duo" and Tech Talks 111461/111466; App Store Connect screenshot sizes;
84 pt rail = width measured in Apple's iOS 27 UI kit. The 24 pt fold band is this kit's design reserve, not an Apple number.
Needs: pip install playwright && playwright install chromium"""
import sys, json, pathlib

POSES = {'iphone': (393, 852), 'outer': (466, 678), 'inner': (951, 669), 'split': (475, 669)}
FOLD_X, FOLD_BAND, RAIL = 475.5, 12, 84

JS = r"""(a) => {
const {pose, rail, fold, band, railW, W, H} = a;
const vis = e => { const r = e.getBoundingClientRect(), s = getComputedStyle(e); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none' && +s.opacity > 0.05 && r.bottom > 0 && r.top < H && r.right > 0 && r.left < W; };
const nm = e => (e.getAttribute('aria-label') || e.innerText || e.value || e.placeholder || e.tagName).trim().replace(/\s+/g,' ').slice(0, 32);
const ctrls = [...document.querySelectorAll('a[href],button,input:not([type=hidden]),select,textarea,[role=button],[role=switch],[role=tab]')].filter(vis).filter(e => !e.parentElement.closest('a[href],button')).filter(e => { const r = e.getBoundingClientRect(); const x = Math.min(Math.max(r.left + r.width / 2, 0), W - 1), y = Math.min(Math.max(r.top + r.height / 2, 0), H - 1); const t = document.elementFromPoint(x, y); return t && (t === e || e.contains(t) || (e.labels && [...e.labels].some(l => l.contains(t)))); });
const lines = [];  // every visible text line box
const tw = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT); let n;
while ((n = tw.nextNode())) { if (!n.textContent.trim() || !n.parentElement || !vis(n.parentElement)) continue;
  const rg = document.createRange(); rg.selectNodeContents(n); for (const r of rg.getClientRects()) if (r.width > 1 && r.bottom > 0 && r.top < H) lines.push({el: n.parentElement, r, t: n.textContent.trim().slice(0, 28)}); }
const R = {};
const vm = document.querySelector('meta[name=viewport]'); R.vw = innerWidth; R.vh = innerHeight; R.meta = vm ? vm.content : '';
// D2 fold
R.fold = [];
if (pose === 'inner') { const a1 = fold - band, a2 = fold + band; const hit = r => r.right > a1 && r.left < a2;
  for (const l of lines) if (hit(l.r) && !l.el.closest('[data-fold-ok]')) R.fold.push(`text "${l.t}" at x ${Math.round(l.r.left)}–${Math.round(l.r.right)}`);
  for (const c of ctrls) { const r = c.getBoundingClientRect(); if (hit(r) && !c.closest('[data-fold-ok]')) R.fold.push(`control "${nm(c)}" at x ${Math.round(r.left)}–${Math.round(r.right)}`); } }
// D3 both halves used
R.halves = [];
if (pose === 'inner') { let L = 0, Rt = 0; for (const l of lines) { if (l.r.right < fold - band) L += l.r.width * l.r.height; else if (l.r.left > fold + band) Rt += l.r.width * l.r.height; }
  if (L < 2000) R.halves.push(`left half has almost no content (${Math.round(L)} pt² of text)`);
  if (Rt < 2000) R.halves.push(`right half has almost no content (${Math.round(Rt)} pt² of text)`);
  const xs = lines.map(l => [l.r.left, l.r.right]); if (xs.length) { const mn = Math.min(...xs.map(x => x[0])), mx = Math.max(...xs.map(x => x[1])); if (mx - mn < 0.6 * W) R.halves.push(`all text sits in a ${Math.round(mx - mn)} pt column (looks letterboxed)`); } }
// D4 rail
R.rail = [];
if (pose === 'outer') { const inStrip = r => rail === 'left' ? r.left < railW - 0.5 : r.right > W - railW + 0.5;
  const railEl = document.querySelector('[data-rail],.rail');
  for (const l of lines) if (inStrip(l.r) && !(railEl && railEl.contains(l.el))) R.rail.push(`text "${l.t}" inside the rail strip`);
  for (const c of ctrls) { const r = c.getBoundingClientRect(); if (inStrip(r) && !(railEl && railEl.contains(c))) R.rail.push(`control "${nm(c)}" inside the rail strip`); }
  if (!railEl) R.rail.push('no side rail found (tab bar should move to the side on the closed display)');
  else { const t = [...railEl.querySelectorAll('a,button,[role=tab]')].filter(vis); if (t.length < 2 || t.length > 5) R.rail.push(`rail has ${t.length} tabs (2–5)`); const un = t.filter(x => !x.innerText.trim()); if (un.length) R.rail.push(`${un.length} rail tabs without a text label`);
    const rr = railEl.getBoundingClientRect(); if (rr.width > railW + 0.5) R.rail.push(`rail is ${Math.round(rr.width)} pt wide (reserve ${railW})`); } }
// D5 bottom bar
R.tabbar = [];
if (pose === 'iphone' || pose === 'split') { const nb = [...document.querySelectorAll('nav')].filter(vis).find(e => e.getBoundingClientRect().bottom >= H - 2);
  if (nb) { const t = [...nb.querySelectorAll('a,button,[role=tab]')].filter(vis); if (t.length < 3 || t.length > 5) R.tabbar.push(`bottom bar has ${t.length} tabs (3–5)`); const un = t.filter(x => !x.innerText.trim()); if (un.length) R.tabbar.push(`${un.length} tabs without a text label`); } }
// D7 / D8 targets
R.small = []; R.tight = [];
const rs = ctrls.map(e => ({e, r: e.getBoundingClientRect()}));
for (const {e, r} of rs) if (r.width < 43.5 || r.height < 43.5) R.small.push(`${e.tagName.toLowerCase()} "${nm(e)}" ${Math.round(r.width)}×${Math.round(r.height)}`);
for (let i = 0; i < rs.length; i++) for (let j = i + 1; j < rs.length; j++) { const A = rs[i].r, B = rs[j].r;
  const dx = Math.max(0, Math.max(A.left, B.left) - Math.min(A.right, B.right)), dy = Math.max(0, Math.max(A.top, B.top) - Math.min(A.bottom, B.bottom));
  if ((dx === 0 && dy > 0 && dy < 8 && (B.left < A.right && A.left < B.right)) || (dy === 0 && dx > 0 && dx < 8 && (B.top < A.bottom && A.top < B.bottom))) R.tight.push(`"${nm(rs[i].e)}" ↔ "${nm(rs[j].e)}" ${Math.round(Math.max(dx, dy))} pt`); }
// D9 text size
R.text = []; const seen = new Set();
for (const l of lines) { if (seen.has(l.el)) continue; seen.add(l.el); const fs = parseFloat(getComputedStyle(l.el).fontSize);
  if (fs < 11) R.text.push(`"${l.t}" ${fs} pt`); else if (fs < 15 && l.el.innerText.length > 80) R.text.push(`paragraph "${l.t}" ${fs} pt`); }
// D11 status area
R.status = []; const top = pose === 'iphone' ? 54 : pose === 'outer' ? 0 : 32;
for (const c of ctrls) { const r = c.getBoundingClientRect(); if (r.top < top - 0.5) R.status.push(`control "${nm(c)}" at y ${Math.round(r.top)} (status area ends at ${top})`); }
// D12 contrast
const parse = c => { const m = c.match(/[\d.]+/g); return m ? m.map(Number) : [0, 0, 0, 0]; };
const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
const bgOf = e => { let layers = []; for (let x = e; x; x = x.parentElement) { const s = getComputedStyle(x); if (/gradient|url\(/.test(s.backgroundImage)) return null; const c = parse(s.backgroundColor); const al = c.length > 3 ? c[3] : 1; if (al > 0) { layers.push([c[0], c[1], c[2], al]); if (al >= 1) break; } }
  let out = [255, 255, 255]; for (const [r, g, b, al] of layers.reverse()) out = [r * al + out[0] * (1 - al), g * al + out[1] * (1 - al), b * al + out[2] * (1 - al)]; return out; };
R.contrast = []; const done = new Set();
for (const l of lines) { if (done.has(l.el)) continue; done.add(l.el); const s = getComputedStyle(l.el); const fg = parse(s.color); const bg = bgOf(l.el); if (!bg) continue;
  const al = fg.length > 3 ? fg[3] : 1; const f = [fg[0] * al + bg[0] * (1 - al), fg[1] * al + bg[1] * (1 - al), fg[2] * al + bg[2] * (1 - al)];
  const L1 = lum(f), L2 = lum(bg), cr = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05); const fs = parseFloat(s.fontSize), bold = +s.fontWeight >= 700;
  const need = (fs >= 24 || (bold && fs >= 18.66)) ? 3 : 4.5; if (cr < need - 0.005) R.contrast.push(`"${l.t}" ${cr.toFixed(2)}:1 (needs ${need})`); }
return R; }"""

CLIP = r"""() => { const out = []; for (const e of document.querySelectorAll('body *')) { if (e.closest('[data-truncate-ok]')) continue; const s = getComputedStyle(e);
  if (!e.innerText || !e.innerText.trim() || e.querySelector('div,main,nav,ul,ol,section,article,aside,header,footer,form')) continue; const r = e.getBoundingClientRect(); if (r.width <= 2 || r.height <= 2 || r.top > innerHeight) continue;
  const cx = e.scrollWidth > e.clientWidth + 1 && /hidden|clip/.test(s.overflowX), cy = e.scrollHeight > e.clientHeight + 1 && /hidden|clip/.test(s.overflowY) && s.overflowY !== 'auto';
  if (cx || cy || (s.textOverflow === 'ellipsis' && e.scrollWidth > e.clientWidth + 1)) out.push(`${e.tagName.toLowerCase()} "${e.innerText.trim().slice(0, 28)}"`); }
  return out.slice(0, 20); }"""

NAMES = {'D1': 'Real frame size for the pose', 'D2': 'Nothing on the fold', 'D3': 'Open display used on both halves', 'D4': 'Side rail clear and labelled',
         'D5': 'Bottom tab bar 3–5 labelled tabs', 'D6': 'No sideways scrolling', 'D7': 'Touch targets ≥ 44 pt', 'D8': '≥ 8 pt between targets',
         'D9': 'Text ≥ 11 pt, paragraphs ≥ 15 pt', 'D10': 'Text at 200% does not clip', 'D11': 'Status / camera area clear', 'D12': 'Text contrast AA'}
APPLIES = {'D2': {'inner'}, 'D3': {'inner'}, 'D4': {'outer'}, 'D5': {'iphone', 'split'}}

def check(pg, url, pose, rail):
    W, H = POSES[pose]
    pg.set_viewport_size({'width': W, 'height': H}); pg.goto(url, wait_until='load'); pg.wait_for_timeout(150)
    R = pg.evaluate(JS, {'pose': pose, 'rail': rail, 'fold': FOLD_X, 'band': FOLD_BAND, 'railW': RAIL, 'W': W, 'H': H})
    ov = pg.evaluate('Math.max(document.documentElement.scrollWidth, document.body.scrollWidth)') - W
    meta_w = next((p.split('=')[1] for p in R['meta'].replace(' ', '').split(',') if p.startswith('width=')), '')
    d1 = [] if meta_w in (str(W), 'device-width') else [f'viewport meta width={meta_w or "missing"}, pose {pose} needs {W}']
    pg.evaluate("() => { for (const e of document.querySelectorAll('body *')) { const fs = parseFloat(getComputedStyle(e).fontSize); e.style.fontSize = (fs * 2) + 'px'; } }")
    pg.wait_for_timeout(100); clip = pg.evaluate(CLIP)
    items = {'D1': d1, 'D2': R['fold'], 'D3': R['halves'], 'D4': R['rail'], 'D5': R['tabbar'], 'D6': [f'{ov} pt wider than the screen'] if ov > 1 else [],
             'D7': R['small'], 'D8': R['tight'], 'D9': R['text'], 'D10': clip, 'D11': R['status'], 'D12': R['contrast']}
    out = []
    for k, v in items.items():
        if k in APPLIES and pose not in APPLIES[k]: out.append({'code': k, 'name': NAMES[k], 'applies': False, 'ok': True, 'items': []})
        else: out.append({'code': k, 'name': NAMES[k], 'applies': True, 'ok': not v, 'items': v[:10], 'count': len(v)})
    return out

def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    if not args: print(__doc__); sys.exit(2)
    opt = lambda k, d=None: next((x.split('=', 1)[1] for x in sys.argv if x.startswith(f'--{k}=')), d)
    target = pathlib.Path(args[0]); files = sorted(target.glob('*.html')) if target.is_dir() else [args[0]]
    from playwright.sync_api import sync_playwright
    res = []
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(device_scale_factor=1, has_touch=True, is_mobile=True)
        for f in files:
            url = f if '://' in str(f) else pathlib.Path(f).resolve().as_uri()
            pose = opt('pose')
            if not pose:
                pg.goto(url); pose = pg.evaluate("(document.querySelector('meta[name=duo-pose]')||{}).content||''") or 'inner'
            res.append({'file': str(f), 'pose': pose, 'checks': check(pg, url, pose, opt('rail', 'left'))})
        b.close()
    L = ['# Duo-ready check', '']
    tot = ok = 0
    for r in res:
        ap = [c for c in r['checks'] if c['applies']]; pas = sum(c['ok'] for c in ap); tot += len(ap); ok += pas
        L.append(f'## {pathlib.Path(r["file"]).name} · {r["pose"]} · {pas}/{len(ap)}')
        for c in ap:
            if not c['ok']: L.append(f'- **{c["code"]} {c["name"]}** — fail ({c["count"]}): ' + '; '.join(c['items'][:4]))
        L.append('')
    L.insert(1, f'Screens: {len(res)} · checks passed: {ok}/{tot}' + (' · all pass' if ok == tot else ''))
    rep = '\n'.join(L)
    if opt('md'): open(opt('md'), 'w').write(rep + '\n')
    if opt('json'): json.dump(res, open(opt('json'), 'w'), indent=1)
    print(rep)
    sys.exit(0 if ok == tot else 1)

if __name__ == '__main__': main()
