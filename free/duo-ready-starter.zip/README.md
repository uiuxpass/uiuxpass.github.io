# Duo-ready starter — by UI/UX Pass (free)

Three common screens rebuilt for iPhone Duo in every pose, plus a script that checks your own screens.

- Templates: List and detail (inbox), Settings, Search and filters
- Poses (points = CSS px): iPhone 393×852 · Duo closed 466×678 · Duo open 951×669 · Split View half 475×669
- Light and dark: 24 HTML screens. Open `index.html`. Add `#fold` to an open screen to see the fold band.
- `duo_check.py`: 12 checks (D1–D12): real frame size, nothing on the fold, both halves used when open, side rail clear when closed, tab bar count, no sideways scroll, 44 pt targets, 8 pt spacing, text size, 200% text, status area, WCAG AA contrast. These 24 screens: 222/222.

## Where the numbers come from
- Duo closed 466×678 pt: outer panel 1398×2034 px at 3x (Apple tech specs).
- Duo open 951×669 pt: App Store Connect inner-display screenshot size 2853×2007 px at 3x. The 890×626 preset in some design tools comes from the panel's 1878×2670 px ÷ 3 and is about 6.9% smaller than what apps render at.
- Tab bars and toolbars move to the side when closed (Apple HIG, "Designing for iPhone Duo"). The 84 pt rail width was measured in Apple's iOS 27 UI kit.
- The 24 pt fold band centred on x = 475.5 is this starter's design reserve, not an Apple number.

## License
Free for personal and commercial work. Don't resell or redistribute the files themselves. All names in the screens are made up. iPhone is a trademark of Apple Inc.; not affiliated with Apple.
