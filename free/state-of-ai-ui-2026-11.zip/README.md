# State of AI-made UI · November 2026 · raw data

Measured by UI/UX Pass (uiuxpass.com). UI/UX Pass also sells Claude skills, so its own skills are not in this test.

## Brief (identical for every run)
"Build a pricing page for a SaaS product called Tallybook, an invoicing tool for freelancers. Include three plans (Free, Pro at $12 per month, Team at $29 per month), a monthly/yearly billing toggle, a feature comparison table and an FAQ. Output one self-contained file named index.html in the current folder: inline CSS and JS, no build step, no external images."
Skill runs were prefixed with "Use the <skill> skill (and no other skill)."; the control run with "Do not use any skill." Exact prompt per run: prompts/.

## Setup
- Date: 24 November 2026, 07:53–08:06 UTC.
- Claude Code 2.1.331, headless (`claude -p`), model claude-opus-5-5, `--setting-sources project --strict-mcp-config`, one fresh folder per run with only that skill in .claude/skills/.
- Allowed tools: Read, Write, Edit, Glob, Grep, Skill, python and ls/cat in Bash. No web access.
- Every transcript shows the Skill tool called with the named skill (not for control).
- 3 runs per skill, 7 groups (6 skills + no-skill control) = 21 pages. Score = median of 3.

## Skill versions (git commit, commit date)
- frontend-design · github.com/anthropics/skills · e4bb5d9 · 2026-11-16
- taste-skill · github.com/Leonxlnx/taste-skill · 6c0b5c7 · 2026-11-22
- ui-ux-pro-max · github.com/nextlevelbuilder/ui-ux-pro-max-skill · f2f7266 · 2026-11-24
- interface-design · github.com/Dammyjay93/interface-design · 2f9be32 · 2026-06-20
- ui-craft · github.com/educlopez/ui-craft · c1e556e · 2026-11-16
- baseline-ui · github.com/ibelick/ui-skills · 7ef0076 · 2026-11-21

## Measurement
- 66 automated browser checks (UI/UX Pass interface-polish check_polish.py, v2.4.0) in Chromium at 1440×900 and 390×844, plus the 8-sign template-look check (check_template.py). Reports: reports/*.polish.json, *.template.json.
- Correction: on 3 pages (frontend-design-2, frontend-design-3, ui-ux-pro-max-3) the only contrast failure was the selected "Monthly" toggle label, reported at about 1.0:1. It is white text on a dark pill (the pill is a separate element behind the text). Confirmed by eye and by sampling rendered pixels (reports/pixel-contrast-audit.json), so that check is counted as a pass there. "raw" in summary.json is the uncorrected score.
- Every page fails the template check "no real product image in the first screen" because the brief asked for no external images. Treat template scores as 7/8 for all.
- External font requests could not load in the test sandbox; the checker reports them as "check online", not as failures.

## Limits
Three runs per skill is small: differences of 1–2 checks are within run-to-run spread. Automated checks measure what is countable, not taste.
